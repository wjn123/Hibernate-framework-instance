package orm;

/**
 * Drug entity. @author MyEclipse Persistence Tools
 */

public class Drug implements java.io.Serializable {

	// Fields

	private String namee;
	private String numm;

	// Constructors

	/** default constructor */
	public Drug() {
	}

	/** minimal constructor */
	public Drug(String namee) {
		this.namee = namee;
	}

	/** full constructor */
	public Drug(String namee, String numm) {
		this.namee = namee;
		this.numm = numm;
	}

	// Property accessors

	public String getNamee() {
		return this.namee;
	}

	public void setNamee(String namee) {
		this.namee = namee;
	}

	public String getNumm() {
		return this.numm;
	}

	public void setNumm(String numm) {
		this.numm = numm;
	}

}