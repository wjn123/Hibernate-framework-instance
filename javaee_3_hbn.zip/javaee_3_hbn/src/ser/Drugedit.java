package ser;

import hiber.HibernateSessionFactory;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import orm.Drug;

public class Drugedit extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		// ��ȡ����
		request.setCharacterEncoding("utf-8");
		String strID = "";
		String strName = "";
		
		strID = request.getParameter("ID");
		strName = request.getParameter("Name");
		
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		Drug drug = (Drug)session.load(Drug.class, strID);
		drug.setNumm(strName);
		
		session.update(drug);
		session.getTransaction().commit();
		session.close();
		
		response.sendRedirect("../DrugList.jsp");
	}

}
